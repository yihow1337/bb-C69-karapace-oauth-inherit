# C69 — Karapace 6.2.4 REST proxy Basic auth inherits service OAUTHBEARER token

**Status:** CONFIRMED locally. **Not submitted.** Bugcrowd-only (Aiven).

## Fingerprint
`Karapace | kafka_rest_apis.get_user_proxy | Authorization: Basic | sasl_oauth_token (service) via OAUTHBEARER client | config.copy() retains service token; Basic path inherits service sasl_mechanism=OAUTHBEARER | CWE-863 / CWE-269 | act as service Kafka principal (ACL bypass of per-user delegation) | rest_authorization=true + sasl_mechanism=OAUTHBEARER + sasl_oauth_token set`

## Quick verify
```bash
python3 poc_oauth_inherit.py
# optional real-module:
# see real_module_check.log (imports evidence/.../authentication.py @ 6.2.4)
```

## Impact
With delegated REST authorization enabled on an OAUTHBEARER-configured cluster, any HTTP client that sends `Authorization: Basic ...` (credentials need not be valid Kafka users) causes the per-user proxy to authenticate to Kafka using the **service** static OAuth token. Per-user Kafka ACLs are bypassed; attacker acts as the service principal.

## Distinct from
CVE-2025-61673 / GHSA-vq25-vcrw-gj53 (Schema Registry missing Authorization header bypass in 5.0.0–5.0.1) — different component, version, and root cause.
